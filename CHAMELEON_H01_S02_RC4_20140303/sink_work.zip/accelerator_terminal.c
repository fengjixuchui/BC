/***********************************************************************************************
* Freescale MMA8451,2,3Q Driver
*
* Filename: terminal.c
*
*
* (c) Copyright 2010, Freescale, Inc.  All rights reserved.
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from Freescale Semiconductor.
*
***********************************************************************************************/
#include "sink_private.h"
#include "sink_debug.h"
#include "accelerator_system.h"

/***********************************************************************************************
* Private macros
***********************************************************************************************/

/***********************************************************************************************
* Private type definitions
***********************************************************************************************/
#ifdef DEBUG_MMA8452QL
#define DEBUG_MMA8452Q(x) DEBUG(x)
#else
#define DEBUG_MMA8452Q(x) 
#endif
/***********************************************************************************************
* Private prototypes
***********************************************************************************************/

uint8 ProcessHexInput (uint8 *in, uint8 *out);
void CopyXYZ (uint8 *ptr);
void CopyXYZ8 (uint8 *ptr);
void PrintXYZdec14 (void);
void PrintXYZdec12 (void);
void PrintXYZdec10(void);
void PrintXYZdec8 (void);
void PrintXYZfrac (void);
void ClearDataFlash (void);
void PrintBuffering (void);
void PrintFIFO (void);
void ReadDataFlashXYZ (void);
void WriteFlashBuffer (void);

/***********************************************************************************************
* Private memory declarations
***********************************************************************************************/


BIT_FIELD StreamMode;                       /* stream mode control flags*/

extern BIT_FIELD RegisterFlag;
extern uint8 value[];                        /* working value result scratchpad*/
#ifdef MMA8452Q_TERMINAL_SUPPORTED
static uint8 temp;                          /*  byte variables*/
static uint8 index;                          /* input character string index*/
#endif
static tword x_value;                       /* 16-bit X accelerometer value*/
static tword y_value;                       /* 16-bit Y accelerometer value*/
static tword z_value;                       /* 16-bit Z accelerometer value*/


extern uint8 functional_block;               /* accelerometer function*/
                                        
const char* ODRvalues [] = 
{
	"800", "400", "200", "100", "50", "12.5", "6.25", "1.563"
};

const char* HPvaluesN [] =
{
	"16", "8", "4", "2",  /*800*/
	"16", "8", "4", "2",  /*400*/
	"8", "4", "2", "1",   /*200*/
	"4", "2", "1", "0.5",   /*100*/
	"2", "1", "0.5", "0.25", /*50*/
	"2", "1", "0.5", "0.25", /*12.5*/
	"2", "1", "0.5", "0.25", /*6.25*/
	"2", "1", "0.5", "0.25"
};

const char* HPvaluesLNLP [] =
{
	"16", "8", "4", "2",
	"16", "8", "4", "2",
	"8", "4", "2", "1",
	"4", "2", "1", "0.5",
	"2", "1", "0.5", "0.25",
	"0.5", "0.25", "0.125", "0.063",
	"0.25", "0.125", "0.063", "0.031",
	"0.063", "0.031", "0.016", "0.008"
};

const char* HPvaluesHiRes [] =
{
	"16", "8", "4", "2"
};

const char* HPvaluesLP [] =
{
	"16", "8", "4", "2",
	"8", "4", "2", "1",
	"4", "2", "1", "0.5",
	"2", "1", "0.5", "0.25",
	"1", "0.5", "0.25", "0.125",
	"0.25", "0.125", "0.063", "0.031",
	"0.125", "0.063", "0.031", "0.016",
	"0.031", "0.016", "0.008", "0.004" 
};

const char* GRange [] =
{
	"2g", "4g", "8g"
};

#ifdef MMA8452Q_TERMINAL_SUPPORTED

/***********************************************************************************************\
* Public functions
\***********************************************************************************************/

/*********************************************************\
**  Terminal Strings
\*********************************************************/
const uint8 string_Prompt []       = {"\r\nMMA845xQ> "};
const uint8 string_What []         = {" <-- what?"};
const uint8 string_Streaming []    = {" - Streaming XYZ data"};
const uint8 string_Counts []       = {" as signed counts\r\n"};  
const uint8 string_Gs []           = {" as signed g's\r\n"};
const uint8 string_Interrupts []   = {" via Int Mode "};
const uint8 string_FIFO []         = {" via FIFO"};

/*********************************************************\
**  Initialize Terminal Interface
\*********************************************************/
void TerminalInit (void)
{

	DEBUG_MMA8452Q(("\r\n\n**  Freescale Semiconductor  **"));
	DEBUG_MMA8452Q  (("\r\n**  MMA845xQ Driver **")); 
	DEBUG_MMA8452Q  (("\r\n**      using the MC9S08QE8  **"));
	DEBUG_MMA8452Q  (("\r\n**                           **"));
	DEBUG_MMA8452Q  (("\r\n**  "__DATE__"    "__TIME__"  **\r\n\n"));
	/*
	**  Prepare Data Flash.
	*/
	address_in[0] = 0;
	address_in[1] = 0;
	address_in[2] = 0;
	address_out[0] = 0;
	address_out[1] = 0;
	address_out[2] = 0;

	functional_block = FBID_MAX;
	StreamMode.Byte = 0;

}


/*********************************************************\
**  Process Terminal Interface
\*********************************************************/

void ProcessTerminal (void)
{
	/*
	**  Output command prompt if required.
	*/
	if (PROMPT_WAIT == FALSE)
	{

		DEBUG_MMA8452Q((uint8*)string_Prompt);

		PROMPT_WAIT = TRUE;
	}
	/*
	**  Get input from terminal.
	*/
	if (SCI_INPUT_READY == TRUE)
	{
		INPUT_ERROR = FALSE;
		/*
		**  Use command line input if not streaming data
		*/
		if ((XYZ_STREAM == FALSE) && (INT_STREAM == FALSE))
		{
			PROMPT_WAIT = FALSE;
			/*
			**  Get first input character - only uppercase
			*/
			switch (BufferRx[0])
			{
				/***************************************************************************************/                 
				case '?':
				/*
				**  Help : list valid commands
				*/              
				DEBUG_MMA8452Q(("\r\nMn  : Mode  1= Standby; 2= 2g; 4= 4g; 8= 8g\r\n"));
				DEBUG_MMA8452Q(("On      : Oversampling 0=Normal 1=LNLP  2=HiRes 3=LP\r\n"));
				DEBUG_MMA8452Q(("ROn     : ODRHz 0=800; 1=400; 2=200; 3=100; 4=50; 5=12.5; 6=6.25; 7=1.56\r\n")); 
				DEBUG_MMA8452Q(("RRxx    : Register xx Read\r\n"));
				DEBUG_MMA8452Q(("RWxx=nn : Register xx Write value nn\r\n"));
				DEBUG_MMA8452Q(("RHn     : High Pass Filter  0 - 3\r\n"));
				DEBUG_MMA8452Q(("RF      : Report ODR speed, HP Filter freq and Mode\r\n"));
				/*DEBUG_MMA8452Q(("Ca      : Data signed counts a=L LPF data a=H HPF data \r\n"));
				//DEBUG_MMA8452Q(("Ga      : XYZ data as signed g's a=L LPF data a=H HPF data \r\n"));  */
				//DEBUG_MMA8452Q(("Saa     : Stream Data: aa CL=CountsLPF,CH=CountsHPF,GL=G'sLPF,GH=G'sHPF\r\n"));             

				DEBUG_MMA8452Q(("Iaan    : Stream Data via Interrupts.\r\n"));
				DEBUG_MMA8452Q(("        : aa CL=CountsLPF, CH=CountsHPF,GL=G'sLPF,GH=G'sHPF INTn\r\n"));
				DEBUG_MMA8452Q(("        : n  1= INT1; 2= INT2\r\n"));

				if (deviceID==1) 
				{
					DEBUG_MMA8452Q(("Faaww   : Stream 14-bit XYZ via FIFO\r\n"));
					DEBUG_MMA8452Q(("        : aa CL=CountsLPF,CH=CountsHPF,GL=G'sLPF,GH=G'sHPF\r\n"));         
					DEBUG_MMA8452Q(("        : ww: Watermark= 1 to 31\r\n"));
				}
				break;

				/***************************************************************************************/
				case 'M':
					/*
					**  Control sensor mode of operation
					*/
					switch (BufferRx[1])
					{

						case '1':
							/*
							**  M1  : Enter Standby
							*/
							DEBUG_MMA8452Q((" - Sensor Standby"));
							MMA845x_Standby();
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case '2':
							/*
							**  M2  : Enter Active 2g
							*/
							DEBUG_MMA8452Q((" - Sensor Active 2g"));
							MMA845x_Standby();
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~FS_MASK));
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | FULL_SCALE_2G));
							full_scale = FULL_SCALE_2G;              
							MMA845x_Active();
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case '4':
							/*
							**  M4  : Enter Active 4g
							*/
							DEBUG_MMA8452Q((" - Sensor Active 4g"));
							MMA845x_Standby();
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~FS_MASK));
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | FULL_SCALE_4G));
							full_scale = FULL_SCALE_4G;
							MMA845x_Active();
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case '8':
							/*
							**  M8  : Enter Active 8g
							*/
							DEBUG_MMA8452Q((" - Sensor Active 8g"));
							MMA845x_Standby();
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~FS_MASK));
							IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | FULL_SCALE_8G));
							full_scale = FULL_SCALE_8G;
							MMA845x_Active();
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						default:
							INPUT_ERROR = TRUE;
						break;
						}
				break;


				case 'O':
					/*
					**  Oversampling Mode Changes
					*/

					switch (BufferRx[1])
					{

						case '0':
							/*
							**  0  : Oversampling Mode: Normal
							*/
							DEBUG_MMA8452Q((" - Oversampling Mode set to Normal"));
							MMA845x_Standby();
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) & ~MODS_MASK));
							MMA845x_Active();
						break;

						case '1':
							/*
							**  1  : Oversampling Mode: LOW NOISE LOW POWER
							*/
							DEBUG_MMA8452Q((" - Oversampling Mode set to Low Noise Low Power"));
							MMA845x_Standby();
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) & ~MODS_MASK));
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) | MODS0_MASK));
							MMA845x_Active();
						break;

						case '2':
							/*
							**  2  : Oversampling Mode: HI RESOLUTION
							*/
							DEBUG_MMA8452Q((" - Oversampling Mode set to Hi Resolution"));
							MMA845x_Standby();
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) & ~MODS_MASK));
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) | MODS1_MASK));
							MMA845x_Active();
						break;

						case '3':
							/*
							**  3  : Oversampling Mode: LOW POWER
							*/
							DEBUG_MMA8452Q((" - Oversampling Mode set to Low Power"));
							MMA845x_Standby();
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) & ~MODS_MASK));
							IIC_RegWrite(CTRL_REG2, (IIC_RegRead(CTRL_REG2) | MODS_MASK));
							MMA845x_Active();
						break;

						default:
							INPUT_ERROR = TRUE;
						break;
						}
				break;


				


				/***************************************************************************************/
				case 'R':
					/*
					**  Sensor register access
					*/
					switch (BufferRx[1])
					{
						/////////////////////////////////////////////////////////////////////////////////////
						case 'R':
						/*
						**  RR xx  : Register Read
						*/
						index = 2;
						/*
						**  Skip past space characters
						*/
						while (BufferRx[index] == ' ')
						{
							index++;
						}
						/*
						**  Process hexadecimal register address input
						*/
						temp = ProcessHexInput (&BufferRx[index], &value[0]);
						if (temp != 0)
						{
							index += temp;
							/*
							**  Check for end of string null
							*/
							if (BufferRx[index++] == 0)
							{
								DEBUG_MMA8452Q(("= "));
								/*
								**  Go read register and report result
								*/
								temp = IIC_RegRead(value[0]);
								hex2ASCII(temp,&value[0]);
								value[2] = 0;
								DEBUG_MMA8452Q((&value[0]));
							}
							else
							{
								INPUT_ERROR = TRUE;
							}
						}
						else
						{
							/*
							**  If no register identified, then read all registers
							*/
							DEBUG_MMA8452Q(("Read All Registers\r\n"));
							for (value[5]=0; value[5]<0x3F;)
							{
								hex2ASCII(value[5],&value[0]);
								value[2] = ' ';
								value[3] = '=';
								value[4] = 0;
								DEBUG_MMA8452Q((&value[0]));

								for (value[4]=4; value[4]!=0; value[4]--)
								{
									value[0] = ' ';
									temp = IIC_RegRead(value[5]++);
									hex2ASCII(temp,&value[1]);
									value[3] = 0;
									DEBUG_MMA8452Q((&value[0]));
								}
								SCI_putCRLF();
							}
						}
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case 'W':
							/*
							**  RW xx = nn  : Register Write
							*/
							index = 2;
							/*
							**  Skip past space characters
							*/
							while (BufferRx[index] == ' ')
							{
								index++;
							}
							/*
							**  Process hexadecimal register address input
							*/
							temp = ProcessHexInput (&BufferRx[index], &value[0]);
							if (temp != 0)
							{
								index += temp;
								/*
								**  Check for "="
								*/
								while (BufferRx[index] == ' ')
								{
									index++;
								}
								if (BufferRx[index++] == '=')
								{
								while (BufferRx[index] == ' ')
								{
								index++;
								}
								/*
								**  Process hexadecimal register data input
								*/
								temp = ProcessHexInput (&BufferRx[index], &value[1]);
								if (temp != 0)
								{
								index += temp;
								/*
								**  Check for end of string null
								*/
								if (BufferRx[index++] == 0)
								{
								/*
								**  Go write register
								*/
								MMA845x_Standby();
								IIC_RegWrite(value[0], value[1]);
								MMA845x_Active();
								/*
								**  Go read register and verify
								*/
								temp = IIC_RegRead(value[0]);
								if (temp == value[1])
								{
								DEBUG_MMA8452Q((" Success"));
								/*
								**  Check and flag if ODR was set to 400Hz or 800Hz
								*/
								if (value[0] == CTRL_REG1)
								{
								if ( ((temp &DR_MASK) == 0) || ((temp &DR_MASK)==8) )   //Checking for 400Hz or 800Hz
								{
								ODR_400 = TRUE;
								} 

								else
								{
								ODR_400 = FALSE;
								}
								}
								}
								else
								{
								DEBUG_MMA8452Q((" Fail"));
								}
								}
								else
								{
								INPUT_ERROR = TRUE;
								}
								}
								else
								{
								INPUT_ERROR = TRUE;
								}
								}
								else
								{
								INPUT_ERROR = TRUE;
								}
								}
							else
							{
							INPUT_ERROR = TRUE;
							}
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case 'O':
						/*
						**  RO n  : Change Output Data Rate Register
						*/
						index = 2;
						/*
						**  Skip past space characters
						*/
						while (BufferRx[index] == ' ')
						{
						index++;
						}
						/*
						**  Accept numerical entries from '0' to '7'
						*/
						value[0] = BufferRx[index] - '0';
						if (value[0] < 8)
						{
						value[0] <<= 3;    //shift the value over by 3 bits
						MMA845x_Standby();
						IIC_RegWrite(, CTRL_REG1,IIC_RegRead(CTRL_REG1) & ~DR_MASK);
						IIC_RegWrite(CTRL_REG1,IIC_RegRead(CTRL_REG1) |value[0]);
						MMA845x_Active();
						/*
						**  Echo back both ODR and HP register values
						*/


						Print_ODR_HP(); // Print Data Rate, Cut-off Frequency for HPF and g-range
						}
						else
						{
						INPUT_ERROR = TRUE;
						}
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case 'H':
						/*
						**  RH n  : Change High Pass Filter Register
						*/
						index = 2;
						/*
						**  Skip past space characters
						*/
						while (BufferRx[index] == ' ')
						{
						index++;
						}
						/*
						**  Accept numerical entries from '0' to '3'
						*/
						value[0] = BufferRx[index] - '0';
						if (value[0] < 4)
						{
						MMA845x_Standby();
						IIC_RegWrite(HP_FILTER_CUTOFF_REG,(IIC_RegRead(HP_FILTER_CUTOFF_REG)& ~SEL_MASK));
						IIC_RegWrite(HP_FILTER_CUTOFF_REG,(IIC_RegRead(HP_FILTER_CUTOFF_REG)| value[0]));
						MMA845x_Active();
						/*
						**  Echo back both ODR and HP register values
						*/
						Print_ODR_HP();
						}
						else
						{
						INPUT_ERROR = TRUE;
						}
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						case 'F':
						/*
						**  RF  : Report ODR and HP Frequencies
						*/
						Print_ODR_HP();
						break;

						/////////////////////////////////////////////////////////////////////////////////////
						default:            
						INPUT_ERROR = TRUE;
						break;
					}
				break;

				

				/////////////////////////////////////////////////////////////////////////////////////////
				case 'I':
				/*
				**  Stream XYZ data via interrupts ICL n  ICH n IGL n IGH n (n=1 or 2)
				*/
				IIC_RegWrite(F_SETUP_REG, 0x00);

				index = 3;
				StreamMode.Byte = 0;
				/*
				**  Skip past space characters
				*/
				while (BufferRx[index] == ' ')
				index++;

				INT_STREAM = TRUE;
				/*
				**  Determine selected output format
				*/
				switch (BufferRx[1])
				{
				/////////////////////////////////////////////////////////////////////////////////////
				case 'C':
				/*
				**  IC a n : Stream XYZ data via INTn as signed counts
				*/
				STREAM_FULLC = TRUE;

				switch (BufferRx[2])
				{
				case 'L':
				/*
				**  LPF Data
				*/
				DEBUG_MMA8452Q((" - Low Pass Filtered Data"));              
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~HPF_OUT_MASK));
				MMA845x_Active();
				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'H':
				/*
				** HPF Data
				*/
				DEBUG_MMA8452Q((" - High Pass Filtered Data"));
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | HPF_OUT_MASK)); 
				MMA845x_Active();
				break;

				default:
				INPUT_ERROR = TRUE;
				break;
				}     
				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'G':
				/*
				**  IG n : Stream  XYZ data via INTn as signed g's
				*/
				STREAM_FULLG = TRUE;
				switch (BufferRx[2])
				{
				case 'L':
				/*
				**  LPF Data
				*/
				DEBUG_MMA8452Q((" - Low Pass Filtered Data"));              
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~HPF_OUT_MASK));
				MMA845x_Active();
				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'H':
				/*
				** HPF Data
				*/
				DEBUG_MMA8452Q((" - High Pass Filtered Data"));
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | HPF_OUT_MASK)); 
				MMA845x_Active();
				break;

				default:
				INPUT_ERROR = TRUE;
				break;
				}    

				break;

				/////////////////////////////////////////////////////////////////////////////////////
				default:
				INPUT_ERROR = TRUE;
				INT_STREAM = FALSE;
				break;
				}
				// End of Main Case Statement for "I"



				if (INT_STREAM == TRUE)
				{
				if (isnum (BufferRx[index]) == TRUE)
				{
				DEBUG_MMA8452Q(((uint8*)string_Streaming));
				DEBUG_MMA8452Q(((uint8*)string_Interrupts));
				SCI_CharOut(BufferRx[index]);
				if (STREAM_FULLC == TRUE)
				{
				DEBUG_MMA8452Q(((uint8*)string_Counts));
				}
				else
				{
				DEBUG_MMA8452Q(((uint8*)string_Gs));
				}
				functional_block = FBID_FULL_XYZ_SAMPLE;
				PROMPT_WAIT = TRUE;
				/*
				**  Configure the interrupt pins for falling edge and open drain output
				*/
				INT_BOTH_FALLING;
				IIC_RegWrite(CTRL_REG3, PP_OD_MASK);
				if (intPinEnableRegister != 0)
				{
				/*
				**  Activate sensor interrupts
				**  - Event set for new Z-axis data
				**  - all functions bypassed
				**  - enable Data Ready interrupt
				**  - route Data Ready to INT2
				*/
				InterruptsActive (0, INT_EN_DRDY_MASK, ~INT_CFG_DRDY_MASK);
				}
				}
				else
				{
				INPUT_ERROR = TRUE;
				INT_STREAM = FALSE;
				}
				}
				break;

				/***************************************************************************************/
				case 'F':
				/*
				**  Stream XYZ data via FIFO interrupts
				*/
				index = 3;   // watermark value
				StreamMode.Byte = 0;
				/*
				**  Skip past space characters
				*/
				while (BufferRx[index] == ' ')
				index++;

				/*
				**  Get the desired FIFO watermark.
				*/
				temp = 0;
				if (isnum (BufferRx[index]) == TRUE)
				{
				temp = BufferRx[index++] - '0';
				if (isnum (BufferRx[index]) == TRUE)
				{
				temp = temp * 10;
				temp += (BufferRx[index++] - '0');
				}
				}

				INT_STREAM = TRUE;
				/*
				**  Determine selected output format
				*/
				switch (BufferRx[1])
				{
				/////////////////////////////////////////////////////////////////////////////////////
				case 'C':
				/*
				**  FC ww : Stream 14-bit XYZ data via FIFO as signed counts using watermark ww
				*/
				DEBUG_MMA8452Q(((uint8*)string_Streaming));
				DEBUG_MMA8452Q(((uint8*)string_FIFO));
				DEBUG_MMA8452Q(((uint8*)string_Counts));
				STREAM_FULLC = TRUE;
				switch (BufferRx[2])
				{
				case 'L':
				/*
				**  LPF Data
				*/
				DEBUG_MMA8452Q((" - Low Pass Filtered Data"));              
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~HPF_OUT_MASK));
				MMA845x_Active();
				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'H':
				/*
				** HPF Data
				*/
				DEBUG_MMA8452Q((" - High Pass Filtered Data"));
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | HPF_OUT_MASK)); 
				MMA845x_Active();
				break;

				default:
				INPUT_ERROR = TRUE;
				break;
				}    

				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'G':
				/*
				**  FG ww : Stream 14-bit XYZ data via FIFO as signed g's using watermark ww
				*/
				DEBUG_MMA8452Q(((uint8*)string_Streaming));
				DEBUG_MMA8452Q(((uint8*)string_FIFO));
				DEBUG_MMA8452Q(((uint8*)string_Gs));
				STREAM_FULLG = TRUE;
				switch (BufferRx[2])
				{
				case 'L':
				/*
				**  LPF Data
				*/
				DEBUG_MMA8452Q((" - Low Pass Filtered Data"));              
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) & ~HPF_OUT_MASK));
				MMA845x_Active();
				break;

				/////////////////////////////////////////////////////////////////////////////////////
				case 'H':
				/*
				** HPF Data
				*/
				DEBUG_MMA8452Q((" - High Pass Filtered Data"));
				MMA845x_Standby();
				IIC_RegWrite(XYZ_DATA_CFG_REG, (IIC_RegRead(XYZ_DATA_CFG_REG) | HPF_OUT_MASK)); 
				MMA845x_Active();
				break;

				default:
				INPUT_ERROR = TRUE;
				break;
				}    

				break;
				/////////////////////////////////////////////////////////////////////////////////////
				default:
				INPUT_ERROR = TRUE;
				INT_STREAM = FALSE;
				break;
				}  // End of Case Statement for "F"

				if (INT_STREAM == TRUE)
				{
				/*
				**  Configure the FIFO
				**  - contains the most recent samples, discarding oldest when overflowed
				**  - set the watermark
				*/
				if (temp > 31)
				temp = 0;
				MMA845x_Standby();
				IIC_RegWrite(F_SETUP_REG, F_MODE0_MASK + temp);

				functional_block = FBID_FIFO;
				PROMPT_WAIT = TRUE;
				/*
				**  Configure the interrupt pins for falling edge and open drain output
				*/
				INT_BOTH_FALLING;
				IIC_RegWrite(CTRL_REG3, PP_OD_MASK);
				MMA845x_Active();

				if (intPinEnableRegister != 0)
				{
				/*
				**  Activate sensor interrupts
				**  - Point to FIFO data
				**  - all functions bypassed
				**  - enable FIFO interrupt
				**  - route FIFO interrupt to INT2
				*/
				InterruptsActive (0, INT_EN_FIFO_MASK, ~INT_CFG_FIFO_MASK);
				}
				/*
				**  Reset FIFO group ID
				*/
				value[5] = 0;
				}
				break;

				/***************************************************************************************/
				default:
				/*
				**  Undefined inputs are ignored.
				*/
				INPUT_ERROR = TRUE;
				break;
				} //end of case statement for main list of options  

			if (INPUT_ERROR == TRUE)
			{
			DEBUG_MMA8452Q(((uint8*)string_What));
			}
			SCI_INPUT_READY = FALSE;
			temp = 0;
			}  
		/*
		**  Data streaming is stopped by any character input.
		*/
		else
		{
		/*
		**  Turn off data streaming
		*/
		INT_PINS_DISABLED;
		POLL_ACTIVE = FALSE;
		XYZ_STREAM = FALSE;
		INT_STREAM = FALSE;
		SCI_INPUT_READY = FALSE;
		PROMPT_WAIT = FALSE;

		/*
		**  If samples were being buffered, output them now.
		*/
		if (ODR_400 == TRUE) 
		{
		SCI_putCRLF();
		address_out[0] = 0;
		address_out[1] = 0;
		address_out[2] = 0;
		/*
		**  Process FIFO formatted data
		*/
		if (functional_block == FBID_FIFO)
		{
		while (ODR_400 == TRUE)
		{
		/*
		**  Read Data Flash samples into the FIFO buffer
		*/
		value[0] = RegisterFlag.Byte & F_CNT_MASK;
		for (value[1]=0; value[1]!=value[0]; value[1]++)
		{
		SPI_SS_SELECT;
		SPI_ChrShift(0x0B);
		SPI_ChrShift(address_out[0]);
		SPI_ChrShift(address_out[1]);
		SPI_ChrShift(address_out[2]);
		SPI_ChrShift(0x00);
		fifo_data[value[1]].Sample.XYZ.x_msb = SPI_ChrShiftR(0x00);
		fifo_data[value[1]].Sample.XYZ.x_lsb = SPI_ChrShiftR(0x00);
		fifo_data[value[1]].Sample.XYZ.y_msb = SPI_ChrShiftR(0x00);
		fifo_data[value[1]].Sample.XYZ.y_lsb = SPI_ChrShiftR(0x00);
		fifo_data[value[1]].Sample.XYZ.z_msb = SPI_ChrShiftR(0x00);
		fifo_data[value[1]].Sample.XYZ.z_lsb = SPI_ChrShiftR(0x00);
		SPI_SS_DESELECT;
		/*
		**  Adjust Data Flash address pointer
		*/
		if (address_out[2] > 245)
		{
		address_out[2] = 0;
		address_out[1]++;
		}
		else
		{
		address_out[2] += 6;
		}
		}
		/*
		**  Print out the FIFO buffer
		*/
		PrintFIFO();
		/*
		**  Check if we're done.
		*/
		if (address_out[0] == address_in[0])
		{
		if (address_out[1] == address_in[1])
		{
		if (address_out[2] == address_in[2])
		{
		ODR_400 = FALSE;
		}
		}
		}
		}
		}
		else
		{
		/*
		**  Read samples stored in Data Flash
		*/
		while (ODR_400 == TRUE)
		{
		ReadDataFlashXYZ();
		/*
		**  Output formats are:
		**    - Stream Full Resolution XYZ data as signed counts
		**    - Stream Full Resolution XYZ data as signed g's
		*/
		if (STREAM_FULLC == 1) 
		{

		//Check Device ID
		switch(deviceID) 
		{
		case 1:
		PrintXYZdec14();            
		break;
		case 2:
		PrintXYZdec12();
		break;
		case 3:
		PrintXYZdec10();
		}
		}
		else
		{
		PrintXYZfrac();
		}
		SCI_putCRLF();
		/*
		**  Adjust Data Flash address pointer
		*/
		if (address_out[2] > 245)
		{
		address_out[2] = 0;
		address_out[1]++;
		}
		else
		{
		address_out[2] += 6;
		}
		/*
		**  Check if we're done.
		*/
		if (address_out[0] == address_in[0])
		{
		if (address_out[1] == address_in[1])
		{
		if (address_out[2] == address_in[2])
		{
		ODR_400 = FALSE;
		}
		}
		}
		}
		}
		/*
		**  Erase the Data Flash
		*/
		ODR_400 = TRUE;
		DEBUG_MMA8452Q(("\r\nErasing Data Flash ... Please wait "));
		while (SCItxActive);
		ClearDataFlash();
		}
		functional_block = FBID_MAX;
		}
		}
	}


/*********************************************************\
**  Terminal Output
\*********************************************************/
void OutputTerminal (uint8 BlockID, uint8 *ptr)
{
  switch (BlockID)
  {
    /////////////////////////////////////////////////////////////////////////////////////////////////
    case FBID_FULL_XYZ_SAMPLE:
      /*
      **  Full Resolution XYZ Sample Registers (0x00 - 0x06)
      */      
      
      CopyXYZ(ptr); 
      
      /*
      **  If the ODR = 400Hz, buffer the samples in the Data Flash.
      */
      if (ODR_400 == TRUE) 
      {
        /*
        **  Provide a visual indication that we're buffering and write to Flash
        */
        PrintBuffering();
        WriteFlashBuffer();
      }
      else
      {
        /*
        **  Output formats are:
        **    - Stream XYZ data as signed counts
        **    - Stream XYZ data as signed g's
        */
        if (STREAM_FULLC == 1)
        {
        
          switch (deviceID)
          {
            case 1:
            PrintXYZdec14();
            break;
            case 2:
            PrintXYZdec12();
            break;
            case 3:
            PrintXYZdec10();
            break;
          }
        
        }
        else
        {
            PrintXYZfrac();
        }
        
        SCI_putCRLF();
      }
      
      break;

    /////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////////////
    case FBID_FIFO:
      /*
      **  FIFO
      **
      **  If the ODR = 400Hz, buffer the samples in the Data Flash.
      */
      if (ODR_400 == TRUE)
      {
        /*
        **  Provide a visual indication that we're buffering
        */
        PrintBuffering();
        /*
        **  Save the samples in the FIFO buffer into the Data Flash
        */
        value[0] = RegisterFlag.Byte & F_CNT_MASK;
        for (value[1]=0; value[1]!=value[0]; value[1]++)
        {
          while (DATAFLASH_Busy() == TRUE);
          /*
          **  Save sample to Data Flash
          */
          DATAFLASH_WriteEnableLatch();
          SPI_SS_SELECT;
          SPI_ChrShift(0x02);
          SPI_ChrShift(address_in[0]);
          SPI_ChrShift(address_in[1]);
          SPI_ChrShift(address_in[2]);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.x_msb);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.x_lsb);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.y_msb);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.y_lsb);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.z_msb);
          SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.z_lsb);
          SPI_SS_DESELECT;
          /*
          **  Adjust Data Flash address pointer
          */
          if (address_in[2] > 245)
          {
            address_in[2] = 0;
            address_in[1]++;
          }
          else
          {
            address_in[2] += 6;
          }
        }
      }
      else
      {
        PrintFIFO();
      }
      break;

    /////////////////////////////////////////////////////////////////////////////////////////////////
    default:
      break;
  }
}


/***********************************************************************************************\
* Private functions
\***********************************************************************************************/

/*********************************************************\
* Print accelerometer's ODR, HP and Mode
\*********************************************************/
void Print_ODR_HP (void)
{
  DEBUG_MMA8452Q(("ODR = "));
  
  if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==0) {
    
    OSMode_Normal=TRUE;
    OSMode_LNLP=FALSE;
    OSMode_HiRes=FALSE;
    OSMode_LP=FALSE;
  } else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==1) {
    
    OSMode_Normal=FALSE;
    OSMode_LNLP=TRUE;
    OSMode_HiRes=FALSE;
    OSMode_LP=FALSE;
  } else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==2) {
    
    OSMode_Normal=FALSE;
    OSMode_LNLP=FALSE;
    OSMode_HiRes=TRUE;
    OSMode_LP=FALSE;  
    } else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==3) {
    OSMode_Normal=FALSE;
    OSMode_LNLP=FALSE;
    OSMode_HiRes=FALSE;
    OSMode_LP=TRUE;
  }
  value[2] = IIC_RegRead(CTRL_REG1);
  value[0] = value[2] & DR_MASK;
  value[0] >>= 1; // move DR value over to the left by 1

  value[1] = value[0] + (IIC_RegRead(HP_FILTER_CUTOFF_REG) & SEL_MASK);
  
  value[0] >>= 2;  // move DR value over to the left by 2 more

  DEBUG_MMA8452Q(((uint8*)ODRvalues[value[0]]));
  DEBUG_MMA8452Q(("Hz   "));
  if (value[0] == 0 || value[0]==1)   //Checking for 400Hz ODR or 800Hz ODR
  {
    ODR_400 = TRUE;
  }
  else
  {
    ODR_400 = FALSE;
  }


  DEBUG_MMA8452Q(("HP = "));
  
  if (OSMode_Normal==TRUE) {
    
  DEBUG_MMA8452Q(((uint8*)HPvaluesN[value[1]]));
  }
  else if (OSMode_LNLP==TRUE)
  {
   DEBUG_MMA8452Q(((uint8*)HPvaluesLNLP[value[1]]));
  }
  else if (OSMode_HiRes==TRUE)
  {
  value[1]=value[1]&0x03;
  DEBUG_MMA8452Q(((uint8*)HPvaluesHiRes[value[1]]));
  } 
  else if (OSMode_LP==TRUE){
  DEBUG_MMA8452Q(((uint8*)HPvaluesLP[value[1]]));
  }
 
    
  DEBUG_MMA8452Q(("Hz   ")); 
  DEBUG_MMA8452Q(("OS Mode = "));
  if (OSMode_Normal==TRUE) 
  {
  DEBUG_MMA8452Q(("Normal   "));
  } 
  else if (OSMode_LNLP==TRUE)
  {
    DEBUG_MMA8452Q(("Low Noise Low Power   "));
  }
  else if (OSMode_HiRes==TRUE){
  DEBUG_MMA8452Q(("Hi Resolution   "));
  } 
  else if (OSMode_LP==TRUE){
  DEBUG_MMA8452Q(("Low Power   "));
  }
   
  DEBUG_MMA8452Q(("G-Range = "));
  DEBUG_MMA8452Q(((uint8*)GRange[full_scale]));
  DEBUG_MMA8452Q(("\n"));
}
  

/*********************************************************\
*
\*********************************************************/
void WriteFlashBuffer (void)
{
  /*
  **  Save sample to Data Flash
  */
  DATAFLASH_WriteEnableLatch();
  SPI_SS_SELECT;
  SPI_ChrShift(0x02);
  SPI_ChrShift(address_in[0]);
  SPI_ChrShift(address_in[1]);
  SPI_ChrShift(address_in[2]);
  SPI_ChrShift(x_value.Byte.hi);  
  SPI_ChrShift(x_value.Byte.lo);
  SPI_ChrShift(y_value.Byte.hi);
  SPI_ChrShift(y_value.Byte.lo);
  SPI_ChrShift(z_value.Byte.hi);
  SPI_ChrShift(z_value.Byte.lo);
  SPI_SS_DESELECT;
  /*
  **  Adjust Data Flash address pointer
  */
  if (address_in[2] > 245)
  {
    address_in[2] = 0;
    address_in[1]++;
  }
  else
  {
    address_in[2] += 6;
  }
}


/*********************************************************\
*
\*********************************************************/
void PrintBuffering (void)
{
  if (temp > 50)
  {
    SCI_putCRLF();
    temp = 0;
    address_out[2] += 50;
    if (address_out[2] < 50)
    {
      address_out[1]++;
      if (address_out[1] == 0)
      {
        address_out[0]++;
      }
    }
  }
  if (temp++ == 0)
  {
    hex2ASCII(address_out[0],&value[0]);
    hex2ASCII(address_out[1],&value[2]);
    value[4] = 0;
    DEBUG_MMA8452Q((&value[0]));
    hex2ASCII(address_out[2],&value[0]);
    value[2] = 0;
    DEBUG_MMA8452Q((&value[0]));
  }
  SCI_CharOut('*');
}


/*********************************************************\
*
\*********************************************************/
void PrintFIFO (void)
{
  /*
  **  Identify if this is either a FIFO Overflow or Watermark event
  */
  if (RegisterFlag.F_OVF_BIT == 1)
  {
    DEBUG_MMA8452Q  (("FIFO Overflow "));
  }
  if (RegisterFlag.F_WMRK_FLAG_BIT == 1)
  {
    DEBUG_MMA8452Q  (("FIFO Watermark "));
  }
  /*
  **  Display FIFO count
  */
  value[0] = RegisterFlag.Byte & F_CNT_MASK;
  hex2ASCII(value[0],&value[1]);
  value[3] = 0;
  DEBUG_MMA8452Q(("0x"));
  DEBUG_MMA8452Q((&value[1]));
  /*
  **  Identify FIFO group
  */
  DEBUG_MMA8452Q ((" group= "));
  hex2ASCII(value[5],&value[1]);
  value[5]++;
  DEBUG_MMA8452Q((&value[1]));
  SCI_putCRLF();
  /*
  **  Output results
  */
  for (value[1]=0; value[1]!=value[0]; value[1]++)
  {
    CopyXYZ(&fifo_data[value[1]].Sample.XYZ.x_msb);
    /*
    **  Output formats are:
    **    - Stream 14-bit XYZ data as signed counts
    **    - Stream 14-bit XYZ data as signed g's
    */
    if (STREAM_FULLC == 1)
    {
      PrintXYZdec14();
    }
    else
    {
      PrintXYZfrac();
    }
    SCI_putCRLF();
  }
}


/*********************************************************\
*
\*********************************************************/
void ReadDataFlashXYZ (void)
{
  SPI_SS_SELECT;
  SPI_ChrShift(0x0B);
  SPI_ChrShift(address_out[0]);
  SPI_ChrShift(address_out[1]);
  SPI_ChrShift(address_out[2]);
  SPI_ChrShift(0x00);
  x_value.Byte.hi = SPI_ChrShiftR(0x00);
  x_value.Byte.lo = SPI_ChrShiftR(0x00);
  y_value.Byte.hi = SPI_ChrShiftR(0x00);
  y_value.Byte.lo = SPI_ChrShiftR(0x00);
  z_value.Byte.hi = SPI_ChrShiftR(0x00);
  z_value.Byte.lo = SPI_ChrShiftR(0x00);
  SPI_SS_DESELECT;
}


/*********************************************************\
*
\*********************************************************/
uint8 ProcessHexInput (uint8 *in, uint8 *out)
{
  uint8 data;

  data = *in++;
  if (ishex(data) == TRUE)
  {
    data = tohex(data);
  }
  else
  {
    return (0);
  }
  if (ishex(*in) == TRUE)
  {
    data <<= 4;
    data += tohex(*in);
    *out = data;
    return (2);
  }
  else if ((*in == ' ') || (*in == 0))
  {
    *out = data;
    return (1);
  }
  return (0);
}


/*********************************************************\
*
\*********************************************************/
void CopyXYZ (uint8 *ptr)
{
  x_value.Byte.hi = *ptr++;
  x_value.Byte.lo = *ptr++;
  y_value.Byte.hi = *ptr++;
  y_value.Byte.lo = *ptr++;
  z_value.Byte.hi = *ptr++; 
  z_value.Byte.lo = *ptr;
       
}

void CopyXYZ8 (uint8 *ptr) 
{
  x_value.Byte.hi = *ptr++;
  x_value.Byte.lo = 0;
  y_value.Byte.hi = *ptr++;
  y_value.Byte.lo = 0;
  z_value.Byte.hi = *ptr; 
  z_value.Byte.lo = 0;
}
  


/*********************************************************\
*
\*********************************************************/
void PrintXYZdec14 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s14dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s14dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s14dec_Out(z_value);
}
/*********************************************************\
*
\*********************************************************/
 void PrintXYZdec12 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s12dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s12dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s12dec_Out(z_value);
}


/*********************************************************\
*
\*********************************************************/
 void PrintXYZdec10 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s10dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s10dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s10dec_Out(z_value);
}

/*********************************************************\
*
\*********************************************************/
void PrintXYZdec8 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s8dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s8dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s8dec_Out(z_value);
}


/*********************************************************\
*
\*********************************************************/
void PrintXYZfrac (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s14frac_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s14frac_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s14frac_Out(z_value);
}

/*********************************************************\
*
\*********************************************************/
void ClearDataFlash (void)
{
  address_in[0] = 0;
  address_in[1] = 0;
  address_in[2] = 0;
  address_out[0] = 0;
  address_out[1] = 0;
  address_out[2] = 0;
}
#else
void Print_ODR_HP (void)
{
	DEBUG_MMA8452Q(("ODR = "));
	
	if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==0) {

		OSMode_Normal=TRUE;
		OSMode_LNLP=FALSE;
		OSMode_HiRes=FALSE;
		OSMode_LP=FALSE;
	} else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==1) {

		OSMode_Normal=FALSE;
		OSMode_LNLP=TRUE;
		OSMode_HiRes=FALSE;
		OSMode_LP=FALSE;
	} else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==2) {

		OSMode_Normal=FALSE;
		OSMode_LNLP=FALSE;
		OSMode_HiRes=TRUE;
		OSMode_LP=FALSE;  
	} else if ((IIC_RegRead(CTRL_REG2) & MODS_MASK)==3) {
		OSMode_Normal=FALSE;
		OSMode_LNLP=FALSE;
		OSMode_HiRes=FALSE;
		OSMode_LP=TRUE;
	}
	value[2] = IIC_RegRead(CTRL_REG1);
	value[0] = value[2] & DR_MASK;
	value[0] >>= 1; /* move DR value over to the left by 1*/

	value[1] = value[0] + (IIC_RegRead(HP_FILTER_CUTOFF_REG) & SEL_MASK);

	value[0] >>= 2;  /* move DR value over to the left by 2 more*/

	DEBUG_MMA8452Q((ODRvalues[value[0]]));
	DEBUG_MMA8452Q(("Hz   "));
	if (value[0] == 0 || value[0]==1)   /*Checking for 400Hz ODR or 800Hz ODR*/
	{
		ODR_400 = TRUE;
	}
	else
	{
		ODR_400 = FALSE;
	}


	DEBUG_MMA8452Q(("HP = "));

	if (OSMode_Normal==TRUE) {

		DEBUG_MMA8452Q((HPvaluesN[value[1]]));
	}
	else if (OSMode_LNLP==TRUE)
	{
		DEBUG_MMA8452Q((HPvaluesLNLP[value[1]]));
	}
	else if (OSMode_HiRes==TRUE)
	{
		value[1]=value[1]&0x03;
		DEBUG_MMA8452Q((HPvaluesHiRes[value[1]]));
	} 
	else if (OSMode_LP==TRUE){
		DEBUG_MMA8452Q((HPvaluesLP[value[1]]));
	}


	DEBUG_MMA8452Q(("Hz   ")); 
	DEBUG_MMA8452Q(("OS Mode = "));
	if (OSMode_Normal==TRUE) 
	{
		DEBUG_MMA8452Q(("Normal   "));
	} 
	else if (OSMode_LNLP==TRUE)
	{
		DEBUG_MMA8452Q(("Low Noise Low Power   "));
	}
	else if (OSMode_HiRes==TRUE){
		DEBUG_MMA8452Q(("Hi Resolution   "));
	} 
	else if (OSMode_LP==TRUE){
		DEBUG_MMA8452Q(("Low Power   "));
	}

	DEBUG_MMA8452Q(("G-Range = "));
	DEBUG_MMA8452Q((GRange[full_scale]));
	DEBUG_MMA8452Q(("\n"));
}

/*********************************************************\
*
\*********************************************************/
void CopyXYZ (uint8 *ptr)
{
  x_value.Byte.hi = *ptr++;
  x_value.Byte.lo = *ptr++;
  y_value.Byte.hi = *ptr++;
  y_value.Byte.lo = *ptr++;
  z_value.Byte.hi = *ptr++; 
  z_value.Byte.lo = *ptr;
       
}

void CopyXYZ8 (uint8 *ptr) 
{
  x_value.Byte.hi = *ptr++;
  x_value.Byte.lo = 0;
  y_value.Byte.hi = *ptr++;
  y_value.Byte.lo = 0;
  z_value.Byte.hi = *ptr; 
  z_value.Byte.lo = 0;
}
  


/*********************************************************\
*
\*********************************************************/
void PrintXYZdec14 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s14dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s14dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s14dec_Out(z_value);
}
/*********************************************************\
*
\*********************************************************/
 void PrintXYZdec12 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s12dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s12dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s12dec_Out(z_value);
}


/*********************************************************\
*
\*********************************************************/
 void PrintXYZdec10 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s10dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s10dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s10dec_Out(z_value);
}

/*********************************************************\
*
\*********************************************************/
void PrintXYZdec8 (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s8dec_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s8dec_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s8dec_Out(z_value);
}


/*********************************************************\
*
\*********************************************************/
void PrintXYZfrac (void)
{
  DEBUG_MMA8452Q(("X= "));
  SCI_s14frac_Out(x_value);
  DEBUG_MMA8452Q(("  Y= "));
  SCI_s14frac_Out(y_value);
  DEBUG_MMA8452Q(("  Z= "));
  SCI_s14frac_Out(z_value);
}

/*********************************************************\
**  Terminal Output
\*********************************************************/
void OutputTerminal (uint8 BlockID, uint8 *ptr)
{
	switch (BlockID)
	{
		
		case FBID_FULL_XYZ_SAMPLE:
			/*
			**  Full Resolution XYZ Sample Registers (0x00 - 0x06)
			*/      

			CopyXYZ(ptr); 

			/*
			**  If the ODR = 400Hz, buffer the samples in the Data Flash.
			*/
			if (ODR_400 == TRUE) 
			{
#if 0
				/*
				**  Provide a visual indication that we're buffering and write to Flash
				*/
				PrintBuffering();
				WriteFlashBuffer();
#endif
			}
			else
			{
				/*
				**  Output formats are:
				**    - Stream XYZ data as signed counts
				**    - Stream XYZ data as signed g's
				*/
				if (STREAM_FULLC == 1)
				{

					switch (deviceID)
					{
						case 1:
							PrintXYZdec14();
						break;
						case 2:
							PrintXYZdec12();
						break;
						case 3:
							PrintXYZdec10();
						break;
					}

				}
				else
				{
					PrintXYZfrac();
				}

				DEBUG_MMA8452Q(("\n"));
			}

		break;

		
		case FBID_FIFO:
#if 0
		/*
		**  FIFO
		**
		**  If the ODR = 400Hz, buffer the samples in the Data Flash.
		*/
		if (ODR_400 == TRUE)
		{
		/*
		**  Provide a visual indication that we're buffering
		*/
		PrintBuffering();
		/*
		**  Save the samples in the FIFO buffer into the Data Flash
		*/
		value[0] = RegisterFlag.Byte & F_CNT_MASK;
		for (value[1]=0; value[1]!=value[0]; value[1]++)
		{
		while (DATAFLASH_Busy() == TRUE);
		/*
		**  Save sample to Data Flash
		*/
		DATAFLASH_WriteEnableLatch();
		SPI_SS_SELECT;
		SPI_ChrShift(0x02);
		SPI_ChrShift(address_in[0]);
		SPI_ChrShift(address_in[1]);
		SPI_ChrShift(address_in[2]);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.x_msb);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.x_lsb);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.y_msb);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.y_lsb);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.z_msb);
		SPI_ChrShift(fifo_data[value[1]].Sample.XYZ.z_lsb);
		SPI_SS_DESELECT;
		/*
		**  Adjust Data Flash address pointer
		*/
		if (address_in[2] > 245)
		{
		address_in[2] = 0;
		address_in[1]++;
		}
		else
		{
		address_in[2] += 6;
		}
		}
		}
		else
		{
		PrintFIFO();
		}
#endif
		break;


		default:
		break;
	}
}

#endif
